import pygame
from colors import Colors


dark_blue = (47, 47, 127)


class Grid:
    def __init__(self):
        self.num_rows = 23
        self.num_cols = 10
        self.cell_size = 20
        self.grid = [[0 for j in range(self.num_cols)] for i in range(self.num_rows)]
        self.colors = Colors.get_tetris_colors()

    #prints the grid
    def print_grid(self):
        for r in range(self.num_rows):
            for c in range(self.num_cols):
                print(self.grid[r][c], end=" ")
            print()

    def grid_reset(self):
        for r in range(self.num_rows):
            for c in range(self.num_cols):
                self.grid[r][c] = 0

    def check_hd_row(self, i):
        tiles = self.get_tile_positions()
        for tile in tiles:
            self.grid.print_grid()
            if not self.grid.big_inside_check(tile.column, -(tile.row+i)) or not self.grid.is_empty(tile.column, -(tile.row+i)):
                print("returns false")
                return False
        return True

    def hd_shadow(self):
        for i in range(-self.grid.num_rows+1, 0):
            if self.check_hd_row(i):
                return i
        return 0

    #checks to see if the pieces are inside the board
    def big_inside_check(self, column, row):
        if row < self.num_rows and 0 <= column < self.num_cols:
            return True
        return False

    #left check
    def is_inside_left(self, column):
        if column >= 0:
            return True
        return False

    #right check
    def is_inside_right(self, column):
        if column < self.num_cols:
            return True
        return False




    #up check
    def is_inside_up(self, row):
        if row < self.num_rows:
            return True
        return False

    #checks to see if part of the board is empty
    def is_empty(self, column, row):
        if self.grid[row][column] == 0:
            return True
        return False

    #checks to see if the row is full
    def is_row_full(self, row):
        for column in range(self.num_cols):
            if self.grid[row][column] == 0:
                return False
        return True

    #helps gets rid of the row when it is cleared
    def clear_row(self, row):
        for column in range(self.num_cols):
            self.grid[row][column] = 0

    #moves all blocks above the clear row down
    def move_row_down(self, row, num_rows):
        for column in range(self.num_cols):
            self.grid[row+num_rows][column] = self.grid[row][column]
            self.grid[row][column] = 0

    #function that clears the whole row
    def clear_full_rows(self):
        completed = 0
        for row in range(self.num_rows-1, 0, -1):
            if self.is_row_full(row):
                self.clear_row(row)
                completed += 1
            elif completed > 0:
                self.move_row_down(row, completed)
        return completed


    #draws pieces to screenz
    def draw(self, screen):
        border = pygame.Rect(218, 58, self.cell_size * self.num_cols + 3, self.cell_size * (self.num_rows - 3) + 3)
        pygame.draw.rect(screen, dark_blue, border)
        for r in (range(0, self.num_rows)):
            for c in range(self.num_cols):
                cell_value = self.grid[r][c]
                cell_rect = pygame.Rect(c * self.cell_size + 220, r * self.cell_size,
                                        self.cell_size - 1, self.cell_size - 1)
                if r < 3 and cell_value == 0:
                    pygame.draw.rect(screen, Colors.black, cell_rect)
                else:
                    pygame.draw.rect(screen, self.colors[cell_value], cell_rect)
