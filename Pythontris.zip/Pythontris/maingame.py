from pygame import event

from gridclass import Grid
from blocktypes import *
import random
from timer import Timer


grid = Grid()

class Game:

    def __init__(self):
        self.lines = 0
        self.level = 0
        self.gravity_speed = (0.8 - ((self.level - 1) * 0.007)) * 1000
        self.down_multiplier = 6
        self.blocks = [LBlock(), JBlock(), OBlock(), IBlock(), TBlock(), SBlock(), ZBlock()]
        self.current_block = self.modern_get_block()
        self.next_block_1 = self.modern_get_block()
        self.next_block_2 = self.modern_get_block()
        self.next_block_3 = self.modern_get_block()
        self.next_block_4 = self.modern_get_block()
        self.next_block_5 = self.modern_get_block()
        self.hold_block = ""

        self.rotate_left_stop = False
        self.rotate_right_stop = False
        self.rotate_180_stop = False
        self.hard_drop_stop = False
        self.hold_stop = False
        self.move_count_on = False
        self.move_count = 0

        self.timers = {
            'move left': Timer(167),
            'move right': Timer(167),
            'move left r': Timer(33),
            'move right r': Timer(33),
            'move down r': Timer(33),
            'gravity speed': Timer(self.gravity_speed),
            'gravity speed plus': Timer(self.gravity_speed / 15),
            'drop block': Timer(500),
        }
        self.first_press_left = False
        self.first_press_right = False
        self.bottomed_out = False
        self.game_over = False
        self.score = 0
        self.attacks = 0
        self.double_check = False
        self.t_spin = False
        self.combo_num = 0
        self.score_name = ""


    def tupdate(self):
        for timer in self.timers.values():
            timer.update()

    def every_check(self):
        if self.block_fits_down():
            self.bottomed_out = False
            self.timers['drop block'].deactivate()
        if self.move_count > 15:
            self.hard_drop()
            self.move_count = 0
            self.move_count_on = False

    def update_score(self, lines_cleared, move_down_points):
        if lines_cleared != 0:
            self.combo_num += 1
            print(self.combo_num)
            if not self.t_spin:
                if lines_cleared == 1:
                    self.score += 40 * (self.level + 1) * self.combo_num
                    self.score_name = "Single"
                elif lines_cleared == 2:
                    self.score += 100 * (self.level + 1) * self.combo_num
                    self.score_name = "Double"
                elif lines_cleared == 3:
                    self.score += 300 * (self.level + 1) * self.combo_num
                    self.score_name = "Triple"
                elif lines_cleared == 4:
                    self.score += 1200 * (self.level + 1) * self.combo_num
                    self.score_name = "Wombat"

            elif self.t_spin:
                if lines_cleared == 1:
                    self.score += 300 * (self.level + 1) * self.combo_num
                    self.score_name = "Mini T-Spin"
                elif lines_cleared == 2:
                    self.score += 1200 * (self.level + 1) * self.combo_num
                    self.score_name = "T-Spin"
                elif lines_cleared == 3:
                    self.score += 2500 * (self.level + 1) * self.combo_num
                    self.score_name = "C-Spin"
                self.t_spin = False

            all_clear_status = True
            for r in range(grid.num_rows):
                for c in range(grid.num_cols):
                    if grid.grid[r][c] != 0:
                        all_clear_status = False
            if all_clear_status:
                self.score += 10000 * (self.level + 1) * self.combo_num
                self.score_name = "All Clear"
            self.lines += lines_cleared
            self.level = int(self.lines / 10)
            self.gravity_speed = (0.8 - ((self.level - 1) * 0.007)) * 1000
            self.timers['gravity speed'] = Timer(self.gravity_speed)
            self.timers['gravity speed plus'] = Timer(self.gravity_speed / 15)
        self.score += move_down_points


        #for r in range


    def reset(self):
        grid.grid_reset()
        self.bottomed_out = False
        self.blocks = [LBlock(), JBlock(), OBlock(), IBlock(), TBlock(), SBlock(), ZBlock()]
        self.current_block = self.modern_get_block()
        self.next_block_1 = self.modern_get_block()
        self.next_block_2 = self.modern_get_block()
        self.next_block_3 = self.modern_get_block()
        self.next_block_4 = self.modern_get_block()
        self.next_block_5 = self.modern_get_block()
        self.hold_block = ""
        self.hold_stop = False
        self.score = 0
        self.lines = 0
        self.level = 0
        self.gravity_speed = (0.8 - ((self.level - 1) * 0.007)) * 1000
        self.timers['gravity speed'] = Timer(self.gravity_speed)
        self.timers['gravity speed plus'] = Timer(self.gravity_speed/15)
        self.combo_num = 0
        self.score_name = ""
        self.game_over = False


    def modern_get_block(self):
        if len(self.blocks) == 0:
            self.blocks = [LBlock(), JBlock(), OBlock(), IBlock(), TBlock(), SBlock(), ZBlock()]
        block = random.choice(self.blocks)
        self.blocks.remove(block)
        return block

    def move_left(self):
        self.current_block.move(-1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(1, 0)
        if self.move_count_on:
            self.move_count += 1

        self.every_check()

    def move_right(self):
        self.current_block.move(1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(-1, 0)
        if self.move_count_on:
            self.move_count += 1

        self.every_check()

    def move_down(self):
        self.current_block.move(0, -1)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(0, 1)
            if not self.bottomed_out or not self.inside_down():
                self.bottomed_out = True
                self.move_count_on = True
                self.timers['drop block'].activate()

        if not self.timers['drop block'].active:
            if self.bottomed_out:
                self.drop_block()
                self.bottomed_out = False
                self.move_count_on = False

    def hold(self):
        if not self.game_over:
            old_block = self.hold_block
            self.current_block.rotation_state = 0
            self.current_block.place_default()
            if self.hold_block == '':
                self.hold_block = self.current_block
                self.block_cycle()
            else:
                self.hold_block = self.current_block
                self.current_block = old_block
            self.hold_stop = True

    def hard_drop(self):
        if not self.game_over:
            move_points = 0
            while self.inside_full() or self.block_fits():
                self.current_block.move(0, -1)
                move_points += 1
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(0, 1)
                    self.update_score(0, move_points)
                    break
            self.drop_block()

    def drop_block(self):
        tiles = self.current_block.get_cell_positions()
        for position in tiles:
            grid.grid[position.row][position.column] = self.current_block.id
        #self.grid.print_grid()

        if not self.game_over:
            rows = grid.clear_full_rows()
            self.update_score(rows, 0)
            if rows == 0:
                self.combo_num = 0
                self.score_name = ""
            self.hold_stop = False
            self.block_cycle()
        if not self.block_fits():
            self.game_over = True
        self.move_count = 0
        self.move_count_on = False

    def block_cycle(self):
        self.current_block = self.next_block_1
        self.next_block_1 = self.next_block_2
        self.next_block_2 = self.next_block_3
        self.next_block_3 = self.next_block_4
        self.next_block_4 = self.next_block_5
        self.next_block_5 = self.modern_get_block()

    def block_fits(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if not grid.is_empty(tile.column, tile.row):
                return False
        return True

    def block_fits_down(self):
        tiles = self.current_block.get_cell_positions()
        m = 0
        for tile in tiles:
            if tile.row < 20:
                if grid.is_empty(tile.column, tile.row + 1) and grid.is_empty(tile.column, tile.row + 2) and grid.is_empty(tile.column, tile.row + 3):
                    m += 1

        if m >= 4 and self.double_check:
            self.move_count_on = False
            self.move_count = 0
            self.double_check = False
        elif m >= 4 and not self.double_check:
            if self.move_count == 15:
                self.move_count = 14
            self.double_check = True
        elif m < 4 and self.double_check:
            self.double_check = False

        for tile in tiles:
            if tile.row < 22:
                if not grid.big_inside_check(tile.column, tile.row) or not grid.is_empty(tile.column, tile.row + 1):
                    return False
            elif tile.row >= 22:
                return False
        return True

    def inside_full(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if not grid.big_inside_check(tile.column, tile.row):
                return False
        return True

    def inside_left(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if not grid.is_inside_left(tile.column):
                return False
        return True

    def inside_right(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if not grid.is_inside_right(tile.column):
                return False
        return True

    def inside_down(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if not grid.is_inside_up(tile.row):
                return False
        return True

    def inside_pieces(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if not grid.is_empty(tile.row, tile.column):
                return False
        return True


    def t_spinner(self):
        corners = 0
        if not grid.big_inside_check(self.current_block.row_offset + 1, self.current_block.column_offset + 1) or not grid.is_empty(self.current_block.row_offset + 1, self.current_block.column_offset + 1):
            corners += 1
        if not grid.big_inside_check(self.current_block.row_offset + 1, self.current_block.column_offset - 1) or not grid.is_empty(self.current_block.row_offset + 1, self.current_block.column_offset - 1):
            corners += 1
        if not grid.big_inside_check(self.current_block.row_offset - 1, self.current_block.column_offset + 1) or not grid.is_empty(self.current_block.row_offset - 1, self.current_block.column_offset + 1):
            corners += 1
        if not grid.big_inside_check(self.current_block.row_offset - 1, self.current_block.column_offset - 1) or not grid.is_empty(self.current_block.row_offset - 1, self.current_block.column_offset - 1):
            corners += 1
        if corners >= 3:
            self.t_spin = True
        else:
            self.t_spin = False

    def rotate_left(self):
        self.current_block.rotate_left()

        if self.move_count <= 15:
            self.timers['drop block'].activate()
        if not self.inside_full() or not self.block_fits():
            if self.current_block.id < 6:
                if self.current_block.rotation_state == 0:
                    self.SRStype2("left")

                elif self.current_block.rotation_state == 1:
                    self.SRStype3("left")

                elif self.current_block.rotation_state == 2:
                    self.SRStype4("left")

                elif self.current_block.rotation_state == 3:
                    self.SRStype1("left")

            elif self.current_block.id == 7:
                if self.current_block.rotation_state == 0:
                    self.SRStype6("left")

                elif self.current_block.rotation_state == 1:
                    self.SRStype7("left")

                elif self.current_block.rotation_state == 2:
                    self.SRStype5("left")

                elif self.current_block.rotation_state == 3:
                    self.SRStype8("left")

        if self.current_block.id == 5:
            self.t_spinner()

        if self.move_count_on:
            self.move_count += 1

        self.every_check()

    def rotate_right(self):
        self.current_block.rotate_right()
        if self.move_count <= 15:
            self.timers['drop block'].activate()

        if not self.inside_full() or not self.block_fits():
            if self.current_block.id < 6:
                if self.current_block.rotation_state == 0:
                    self.SRStype4("right")

                elif self.current_block.rotation_state == 1:
                    self.SRStype3("right")

                elif self.current_block.rotation_state == 2:
                    self.SRStype2("right")

                elif self.current_block.rotation_state == 3:
                    self.SRStype1("right")

            elif self.current_block.id == 7:
                if self.current_block.rotation_state == 0:
                    self.SRStype8("right")

                elif self.current_block.rotation_state == 1:
                    self.SRStype6("right")

                elif self.current_block.rotation_state == 2:
                    self.SRStype7("right")

                elif self.current_block.rotation_state == 3:
                    self.SRStype5("right")

        if self.current_block.id == 5:
            self.t_spinner()

        if self.move_count_on:
            self.move_count += 1

        self.every_check()

    def SRStype1(self, rotateType):  # 0>3 and 2>3
        self.current_block.move(-1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(0, 1)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(1, -3)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(-1, 0)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(1, 2)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def SRStype2(self, rotateType):  # 3>0 and 3>2
        self.current_block.move(1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(0, -1)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(-1, 3)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(1, 0)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(-1, -2)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def SRStype3(self, rotateType):  # 0>1 and2>1
        self.current_block.move(1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(0, 1)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(-1, -3)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(1, 0)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(-1, 2)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def SRStype4(self, rotateType):  # 1>0 and 1>2
        self.current_block.move(-1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(0, -1)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(1, 3)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(-1, 0)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(1, -2)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def SRStype5(self, rotateType):  # 0>3(R) and 1>2(L)
        self.current_block.move(-2, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(3, 0)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(-3, -1)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(3, 3)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(-1, -2)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def SRStype6(self, rotateType):  # 3>0(L) and 2>1(R)
        self.current_block.move(2, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(-3, 0)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(3, 1)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(-3, -3)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(1, 2)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def SRStype7(self, rotateType):  # 0>1(L) and 3>2(R)
        self.current_block.move(-1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(3, 0)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(-3, 2)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(3, -3)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(-2, 1)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def SRStype8(self, rotateType):  # 1>0(R) and 2>3(L)
        self.current_block.move(1, 0)
        if not self.inside_full() or not self.block_fits():
            self.current_block.move(-3, 0)
            if not self.inside_full() or not self.block_fits():
                self.current_block.move(3, -2)
                if not self.inside_full() or not self.block_fits():
                    self.current_block.move(-3, 3)
                    if not self.inside_full() or not self.block_fits():
                        self.current_block.move(2, -1)
                        if rotateType == "left":
                            self.current_block.rotate_right()
                        elif rotateType == "right":
                            self.current_block.rotate_left()

    def rotate_180(self):
        self.current_block.rotate_180()
        if self.move_count <= 15:
            self.timers['drop block'].activate()

        if not self.inside_right():
            self.current_block.move(0, -1)
        elif not self.inside_left():
            self.current_block.move(0, 1)
        elif not self.inside_down():
            self.current_block.move(-1, 0)
        if self.move_count_on:
            self.move_count += 1

        self.every_check()

    def draw(self, screen):
        grid.draw(screen)
        self.current_block.draw_hard_drop(screen)
        self.current_block.draw(screen, 220, 0)

        if (self.hold_block != ""):
            self.hold_block.draw(screen, 480, 20)
        self.next_block_1.draw(screen, 480, 80)
        self.next_block_2.draw(screen, 480, 140)
        self.next_block_3.draw(screen, 480, 200)
        self.next_block_4.draw(screen, 480, 260)
        self.next_block_5.draw(screen, 480, 320)
