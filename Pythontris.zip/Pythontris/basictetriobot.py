import pygame
import sys

from colors import Colors
from maingame import Game

black = (0, 0, 0)

pygame.init()

#makes the display
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("KunkyFong Block Game")

clock = pygame.time.Clock()
game = Game()

game_font = pygame.font.Font(None, 40)
game_big_font = pygame.font.Font(None, 72)
hold_text = game_font.render("Hold", True, Colors.white)
next_text = game_font.render("Next", True, Colors.white)
score_text = game_font.render("Score: " + str(game.score), True, Colors.white)
level_text = game_font.render("Level: " + str(game.level), True, Colors.white)
game_over_text = game_big_font.render("Game Over", True, Colors.white)
r_text = game_font.render("R to Reset", True, Colors.white)
score_type_text = game_font.render(str(game.score_name), True, Colors.white)
combo_text = game_font.render("", True, Colors.white)

GAME_UPDATE = pygame.USEREVENT
pygame.time.set_timer(GAME_UPDATE, 10)
while True:
    game.tupdate()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        keys = pygame.key.get_pressed()

        if not keys[pygame.K_DOWN] and not game.timers['gravity speed'].active:
            game.move_down()
            game.timers['gravity speed'].activate()

        elif keys[pygame.K_DOWN] and not game.timers['gravity speed plus'].active:
            game.move_down()
            game.timers['gravity speed plus'].activate()
            if not game.bottomed_out and not game.game_over:
                game.update_score(0, 1)

        if keys[pygame.K_LEFT]:
            if not game.timers['move left'].active and not game.first_press_left:
                game.move_left()
                game.first_press_left = True
                game.timers['move left'].activate()
            elif not game.timers['move left r'].active and not game.timers['move left'].active and game.first_press_left:
                game.move_left()
                game.timers['move left r'].activate()

        elif keys[pygame.K_RIGHT]:
            if not game.timers['move right'].active and not game.first_press_right:
                game.move_right()
                game.first_press_right = True
                game.timers['move right'].activate()
            elif not game.timers['move right r'].active and not game.timers['move right'].active and game.first_press_right:
                game.move_right()
                game.timers['move right r'].activate()

        if not keys[pygame.K_LEFT]:
            game.first_press_left = False

        if not keys[pygame.K_RIGHT]:
            game.first_press_right = False

        if event.type == pygame.KEYDOWN:
            if keys[pygame.K_SPACE] and game.hard_drop_stop == False:
                game.hard_drop()
                game.hard_drop_stop = True
                game.bottomed_out = False

            if keys[pygame.K_c] and game.hold_stop == False:
                game.hold()

            if keys[pygame.K_z] and game.rotate_left_stop == False:
                game.rotate_left()
                game.rotate_left_stop = True

            elif keys[pygame.K_x] and game.rotate_right_stop == False:
                game.rotate_right()
                game.rotate_right_stop = True

            elif keys[pygame.K_a] and game.rotate_180_stop == False:
                game.rotate_180()
                game.rotate_180_stop = True

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                game.hard_drop_stop = False
            if event.key == pygame.K_z:
                game.rotate_left_stop = False
            if event.key == pygame.K_x:
                game.rotate_right_stop = False
            if event.key == pygame.K_a:
                game.rotate_180_stop = False

        if keys[pygame.K_r]:
            game.reset()

        score_text = game_font.render("Score: " + str(game.score), True, Colors.white)
        level_text = game_font.render("Level: " + str(game.level), True, Colors.white)
        if game.combo_num >= 2:
            combo_text = game_font.render("Combo: " + str(game.combo_num), True, Colors.white)
        else:
            combo_text = game_font.render("", True, Colors.white)
        score_type_text = game_font.render(str(game.score_name), True, Colors.white)


    #draws the board

    screen.fill(black)
    screen.blit(hold_text, (440, 20, 50, 50))
    screen.blit(next_text, (440, 80, 50, 50))
    screen.blit(level_text, (440, 390, 50, 50))
    screen.blit(score_text, (440, 420, 50, 50))
    screen.blit(score_type_text, (50, 290, 50, 50))
    screen.blit(combo_text, (50, 320, 50, 50))



    game.draw(screen)

    if game.game_over:
        screen.blit(game_over_text, (180, 180, 50, 50))
        screen.blit(r_text, (250, 240, 50, 50))

    pygame.display.update()
    clock.tick(60)
