class Colors:
    grey = (40, 40, 40)
    green = (57, 255, 20)
    red = (255, 91, 91)
    blue = (31, 81, 255)
    purple = (255, 0, 255)
    orange = (255, 165, 0)
    yellow = (255, 255, 0)
    cyan = (0, 255, 255)
    dark_blue = (47, 47, 127)
    white = (255, 255, 255)
    black = (0, 0, 0)


    @classmethod
    def get_tetris_colors(cls):
        return [cls.grey, cls.green, cls.red, cls.blue, cls.orange, cls.purple, cls.yellow, cls.cyan, cls.dark_blue, cls.white, cls.black]
