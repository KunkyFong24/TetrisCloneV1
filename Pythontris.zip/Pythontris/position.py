class Position:
    def __init__(self, column, row):
        self.row = row
        self.column = column
        