from colors import Colors
import pygame
from position import Position
from gridclass import Grid
import maingame


class Block:
    def __init__(self, id):

        self.id = id
        self.cells = {}
        self.cell_size = 20
        self.rotation_state = 0
        self.colors = Colors.get_tetris_colors()
        self.row_offset = 0
        self.column_offset = 0
        self.grid = maingame.grid

    def draw(self, screen, offset_x, offset_y):
        tiles = self.get_cell_positions()
        for tile in tiles:
            tile_rect = pygame.Rect(tile.column * self.cell_size + offset_x, tile.row * self.cell_size + offset_y,
                                    self.cell_size - 1, self.cell_size - 1)
            pygame.draw.rect(screen, self.colors[self.id], tile_rect)

    def hd_shadow(self):
        blockcheck = False
        for i in range(self.row_offset, self.grid.num_rows):
            tiles = self.get_tile_positions()
            for tile in tiles:
                if not self.grid.big_inside_check(tile.column, i + tile.row) or not self.grid.is_empty(tile.column, i + tile.row):
                    blockcheck = True

            if blockcheck == True:
                return i-1
        return i-1



    def draw_hard_drop(self, screen):
        tiles = self.get_cell_positions()
        for tile in tiles:
            tile_rect = pygame.Rect(tile.column * self.cell_size + 220, self.cell_size * (tile.row - self.row_offset + self.hd_shadow()),
                                    self.cell_size - 1, self.cell_size - 1)
            pygame.draw.rect(screen, (255, 255, 255, 0.7), tile_rect)

    def move(self, columns, rows):
        self.row_offset -= rows
        self.column_offset += columns

    def place_default(self):
        self.row_offset = 0
        if self.id < 6:
            self.column_offset = 3
        elif self.id > 6:
            self.column_offset = 3
        elif self.id == 6:
            self.column_offset = 4
    def get_cell_positions(self):
        tiles = self.cells[self.rotation_state]
        moved_tiles = []
        for position in tiles:
            position = Position(position.column + self.column_offset, position.row + self.row_offset)
            moved_tiles.append(position)
        return moved_tiles

    def get_tile_positions(self):
        tiles = self.cells[self.rotation_state]
        moved_tiles = []
        for position in tiles:
            position = Position(position.column + self.column_offset, position.row)
            moved_tiles.append(position)
        return moved_tiles



    def rotate_left(self):
        self.rotation_state += 1
        if self.rotation_state >= len(self.cells):
            self.rotation_state = self.rotation_state % 4

    def rotate_right(self):
        self.rotation_state -= 1
        if self.rotation_state < 0:
            self.rotation_state = self.rotation_state % 4

    def rotate_180(self):
        self.rotation_state += 2
        if self.rotation_state >= len(self.cells):
            self.rotation_state = self.rotation_state % 4

